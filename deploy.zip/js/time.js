// Mecânicas de tempo (primeira versão: só o relógio aparecendo)
const timeState = {
  elapsed: 0,
  paused: false,
};

function updateTime(dt) {
  if (!timeState.paused) timeState.elapsed += dt;
}

function drawTimeHUD(ctx) {
  ctx.fillStyle = "#fff";
  ctx.font = "16px monospace";
  const seg = Math.floor(timeState.elapsed / 1000);
  ctx.fillText("Tempo: " + seg + "s" + (timeState.paused ? " (PAUSADO)" : ""), 10, ctx.canvas.height - 12);
}
