// Loop principal do jogo
const canvas = document.getElementById("game");
const ctx = canvas.getContext("2d");

function resize() {
  canvas.width = window.innerWidth;
  canvas.height = window.innerHeight;
}
window.addEventListener("resize", resize);
resize();

let lastTime = performance.now();

function loop(now) {
  const dt = now - lastTime;
  lastTime = now;

  updatePlayer();
  updateTime(dt);

  const offsetX = Math.floor((canvas.width - MAP_W * TILE) / 2);
  const offsetY = Math.floor((canvas.height - MAP_H * TILE) / 2);

  ctx.clearRect(0, 0, canvas.width, canvas.height);
  drawWorld(ctx, offsetX, offsetY);
  drawPlayer(ctx, offsetX, offsetY);
  drawTimeHUD(ctx);

  requestAnimationFrame(loop);
}

requestAnimationFrame(loop);
