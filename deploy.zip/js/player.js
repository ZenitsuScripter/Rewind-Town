// Movimento e desenho do personagem
const player = {
  x: 5 * TILE,
  y: 5 * TILE,
  size: 24,
  speed: 2.5,
};

const keys = {};
window.addEventListener("keydown", e => keys[e.key] = true);
window.addEventListener("keyup", e => keys[e.key] = false);

function updatePlayer() {
  let dx = 0, dy = 0;
  if (keys["ArrowLeft"]) dx -= 1;
  if (keys["ArrowRight"]) dx += 1;
  if (keys["ArrowUp"]) dy -= 1;
  if (keys["ArrowDown"]) dy += 1;

  const nx = player.x + dx * player.speed;
  const ny = player.y + dy * player.speed;

  if (!collides(nx, player.y)) player.x = nx;
  if (!collides(player.x, ny)) player.y = ny;
}

function collides(px, py) {
  const s = player.size;
  const corners = [
    [px, py], [px + s, py], [px, py + s], [px + s, py + s]
  ];
  return corners.some(([cx, cy]) =>
    isWall(Math.floor(cx / TILE), Math.floor(cy / TILE))
  );
}

function drawPlayer(ctx, offsetX, offsetY) {
  ctx.fillStyle = "#ffcc00";
  ctx.fillRect(offsetX + player.x, offsetY + player.y, player.size, player.size);
}
