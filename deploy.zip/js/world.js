// Mapa e objetos da cidade
const TILE = 32;
const MAP_W = 20;
const MAP_H = 15;

// 0 = chão, 1 = parede
const map = [];
for (let y = 0; y < MAP_H; y++) {
  const row = [];
  for (let x = 0; x < MAP_W; x++) {
    const borda = x === 0 || y === 0 || x === MAP_W - 1 || y === MAP_H - 1;
    row.push(borda ? 1 : 0);
  }
  map.push(row);
}

function drawWorld(ctx, offsetX, offsetY) {
  for (let y = 0; y < MAP_H; y++) {
    for (let x = 0; x < MAP_W; x++) {
      ctx.fillStyle = map[y][x] === 1 ? "#4a4a5a" : "#3a6b3a";
      ctx.fillRect(offsetX + x * TILE, offsetY + y * TILE, TILE, TILE);
    }
  }
}

function isWall(tx, ty) {
  if (tx < 0 || ty < 0 || tx >= MAP_W || ty >= MAP_H) return true;
  return map[ty][tx] === 1;
}
